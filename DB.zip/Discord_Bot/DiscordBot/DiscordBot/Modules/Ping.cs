﻿using Discord;
using Discord.Commands;
using Discord.WebSocket;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace DiscordBot.Modules
{
    [Group("ping")]
    public class Ping : ModuleBase<SocketCommandContext> 
    {
        [Command]
        public async Task DefaultPing()
        {
            await ReplyAsync("Pong!");
        }

        [Command("user")]
        public async Task UserPing(SocketGuildUser user)
        {
            
            for (int i = 0; i < 10; i++)
            {
                await ReplyAsync($"Pong! {user.Mention}");
            }
        }

        

       
   

        //EmbedBuilder builder = new EmbedBuilder();
        //.WithTitle("ping!").WithDescription("This is a really nice ping!").WithColor(Color.DarkTeal);
        //builder.AddField("Firld1", "Test").AddInlineField("Field2", "Test").AddInlineField("Field3", "Test");
        //await ReplyAsync($"{Context.Client.CurrentUser.Mention} || {Context.User.Mention} sent {Context.Message.Content} in  {Context.Guild.Name}!");

        //await ReplyAsync("", false, builder.Build());

        //Context.User;
        //Context.Client;
        //Context.Guild;
        //Context.Message;
        //Context.Channel;
    }
}
